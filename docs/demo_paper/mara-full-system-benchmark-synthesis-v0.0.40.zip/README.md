# MARA v0.0.40 Full-System Benchmark Synthesis Artifact

This supplementary bundle accompanies the MARA demo paper. The software release anchor is:
https://github.com/262412/MARA/releases/tag/v0.0.40

The bundle contains sanitized public copies of the full-system benchmark synthesis outputs used by the paper: aggregate result tables, route-decision diagnostics, latency/backend summaries, paired route deltas, bootstrap intervals, oracle-regret diagnostics, win/loss/tie comparisons, the input artifact manifest, per-example metric records, the Slurm submission ledger, and the synthesis script.

Environment-specific absolute runtime locations from the original HPC run have been replaced with <BENCHMARK_RUN_ROOT> or <SYNTHESIS_DIR>. Those references identify the artifact family used to build each row; they are not required as accessible local paths for paper review. Forty-character hexadecimal values in example_id fields are dataset/example identifiers, not software version anchors. Scores and backend metadata should be read from the CSV/Markdown files in this bundle.
