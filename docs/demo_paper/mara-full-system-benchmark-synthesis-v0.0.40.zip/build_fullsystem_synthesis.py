#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from benchmark.statistical_significance import (
    bootstrap_ci_by_dataset_route,
    controller_oracle_regret_rows,
    paired_route_delta_rows,
    route_win_loss_tie_rows,
)


SYNTHESIS_DIR = Path(__file__).resolve().parent
RUN_ROOT = SYNTHESIS_DIR.parent
JOB_TABLE = SYNTHESIS_DIR / "slurm_submission_jobs.tsv"
REQUIRED_ARTIFACTS = ("summary.json", "route_metrics.csv", "predictions.jsonl", "report.md")

OUTPUTS = {
    "input_manifest": SYNTHESIS_DIR / "statistical_synthesis_input_manifest.csv",
    "main": SYNTHESIS_DIR / "statistical_main_result_table.csv",
    "route_decision": SYNTHESIS_DIR / "statistical_route_decision_summary.csv",
    "failure_latency_backend": SYNTHESIS_DIR / "statistical_failure_latency_backend_table.csv",
    "paired_delta": SYNTHESIS_DIR / "statistical_paired_route_delta.csv",
    "bootstrap_ci": SYNTHESIS_DIR / "statistical_bootstrap_ci_by_route.csv",
    "controller_oracle_regret": SYNTHESIS_DIR / "statistical_controller_oracle_regret.csv",
    "win_loss_tie": SYNTHESIS_DIR / "statistical_win_loss_tie_table.csv",
    "per_example_records": SYNTHESIS_DIR / "statistical_per_example_metric_records.csv",
    "report": SYNTHESIS_DIR / "statistical_synthesis_report.md",
}

PAIRED_ROUTE_PAIRS: dict[str, list[tuple[str, str]]] = {
    "financebench": [
        ("direct_answer", "controller_auto"),
        ("text_rag", "controller_auto"),
        ("crag_guarded", "controller_auto"),
    ],
    "qasper": [
        ("text_rag", "controller_auto"),
        ("crag_guarded", "controller_auto"),
    ],
    "ragtruth": [
        ("text_rag", "controller_auto"),
        ("crag_guarded", "controller_auto"),
    ],
    "alce_asqa": [
        ("text_rag", "controller_auto"),
        ("crag_guarded", "controller_auto"),
    ],
    "slidevqa": [
        ("page_image_rag_vlm", "controller_auto"),
    ],
    "mmdocrag": [
        ("text_rag", "controller_auto"),
        ("element_rag", "controller_auto"),
        ("page_image_rag_vlm", "controller_auto"),
        ("hybrid_rag", "controller_auto"),
    ],
}


def main() -> None:
    args = parse_args()
    jobs = read_csv(JOB_TABLE, delimiter="\t")
    artifact_rows = [artifact_manifest_row(job) for job in jobs]
    write_csv(OUTPUTS["input_manifest"], artifact_rows)

    incomplete = [row for row in artifact_rows if row["artifacts_complete"] != "True"]
    if incomplete and not args.allow_partial:
        write_report(
            artifact_rows=artifact_rows,
            main_rows=[],
            route_decision_rows=[],
            failure_rows=[],
            records=[],
            paired_rows=[],
            bootstrap_rows=[],
            oracle_rows=[],
            win_loss_rows=[],
            blocked_reason="Incomplete Slurm artifact set; rerun with --allow-partial only for progress debugging.",
        )
        raise SystemExit(
            f"{len(incomplete)} job artifacts are incomplete; see {OUTPUTS['input_manifest']}"
        )

    records: list[dict[str, Any]] = []
    route_decision_rows: list[dict[str, Any]] = []
    for artifact in artifact_rows:
        if artifact["artifacts_complete"] != "True":
            continue
        predictions = read_jsonl(Path(str(artifact["predictions_jsonl"])))
        records.extend(per_example_records(artifact, predictions))
        route_decision_rows.extend(route_decision_summary_rows(artifact, predictions))

    main_rows = aggregate_main_rows(records)
    failure_rows = aggregate_failure_latency_backend_rows(records)
    paired_rows, bootstrap_rows, win_loss_rows = statistical_rows(records)
    oracle_rows = controller_oracle_regret_by_dataset(records)

    write_csv(OUTPUTS["main"], main_rows)
    write_csv(OUTPUTS["route_decision"], route_decision_rows)
    write_csv(OUTPUTS["failure_latency_backend"], failure_rows)
    write_csv(OUTPUTS["paired_delta"], paired_rows)
    write_csv(OUTPUTS["bootstrap_ci"], bootstrap_rows)
    write_csv(OUTPUTS["controller_oracle_regret"], oracle_rows)
    write_csv(OUTPUTS["win_loss_tie"], win_loss_rows)
    write_csv(OUTPUTS["per_example_records"], records)
    partial_reason = (
        "Partial synthesis only; not all Slurm artifact sets are complete."
        if incomplete
        else ""
    )
    write_report(
        artifact_rows=artifact_rows,
        main_rows=main_rows,
        route_decision_rows=route_decision_rows,
        failure_rows=failure_rows,
        records=records,
        paired_rows=paired_rows,
        bootstrap_rows=bootstrap_rows,
        oracle_rows=oracle_rows,
        win_loss_rows=win_loss_rows,
        blocked_reason=partial_reason,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--allow-partial",
        action="store_true",
        help="Generate progress tables from completed artifacts only.",
    )
    return parser.parse_args()


def artifact_manifest_row(job: dict[str, str]) -> dict[str, Any]:
    output_subdir = "01_core_text" if job["kind"] == "text" else "05_page_image_vlm"
    artifact_dir = find_artifact_dir(RUN_ROOT / output_subdir, job["suite_name"])
    artifact_dir_text = str(artifact_dir) if artifact_dir else ""
    complete = bool(artifact_dir) and all((artifact_dir / name).exists() for name in REQUIRED_ARTIFACTS)
    summary = read_json(artifact_dir / "summary.json") if artifact_dir else {}
    predictions = read_jsonl(artifact_dir / "predictions.jsonl") if artifact_dir else []
    return {
        "job_id": job["job_id"],
        "kind": job["kind"],
        "dataset": job["dataset"],
        "route_request": job["route"],
        "shard_index": job["shard_index"],
        "num_shards": job["num_shards"],
        "limit": job["limit"],
        "timeout_seconds": job["timeout_seconds"],
        "partition": job["partition"],
        "gres": job["gres"],
        "suite_name": job["suite_name"],
        "manifest": job["manifest"],
        "artifact_dir": artifact_dir_text,
        "artifacts_complete": str(complete),
        "num_examples": summary.get("num_examples", ""),
        "num_predictions": len(predictions),
        "summary_json": str(artifact_dir / "summary.json") if artifact_dir else "",
        "route_metrics_csv": str(artifact_dir / "route_metrics.csv") if artifact_dir else "",
        "predictions_jsonl": str(artifact_dir / "predictions.jsonl") if artifact_dir else "",
        "report_md": str(artifact_dir / "report.md") if artifact_dir else "",
    }


def find_artifact_dir(root: Path, suite_name: str) -> Path | None:
    if not root.exists():
        return None
    matches = sorted(
        path
        for path in root.iterdir()
        if path.is_dir() and path.name.startswith("2026") and suite_name in path.name
    )
    return matches[-1] if matches else None


def per_example_records(
    artifact: dict[str, Any],
    predictions: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for item in predictions:
        metrics = dict_or_empty(item.get("metrics"))
        performance = dict_or_empty(item.get("performance"))
        decision = controller_decision(item)
        backend = dict_or_empty(item.get("backend_metadata"))
        rows.append(
            {
                "dataset": artifact["dataset"],
                "job_id": artifact["job_id"],
                "suite_name": artifact["suite_name"],
                "artifact_dir": artifact["artifact_dir"],
                "route_request": artifact["route_request"],
                "shard_index": artifact["shard_index"],
                "example_id": str(item.get("example_id") or item.get("question_id") or ""),
                "question": str(item.get("question") or item.get("benchmark_question") or ""),
                "route": str(item.get("route") or ""),
                "error": str(item.get("error") or ""),
                "error_type": str(item.get("error_type") or ""),
                "answer_for_scoring_empty": str(not bool(str(item.get("answer_for_scoring") or "").strip())),
                "f1": metric(metrics, "f1"),
                "native_score": metric(metrics, "native_score"),
                "mara_score": metric(metrics, "mara_score"),
                "em": metric(metrics, "em"),
                "numeric_match": metric(metrics, "numeric_match"),
                "page_hit": metric(metrics, "page_hit"),
                "element_hit": metric(metrics, "element_hit"),
                "citation_inline_recall": metric(metrics, "citation_inline_recall"),
                "citation_metadata_recall": metric(metrics, "citation_metadata_recall"),
                "false_abstention": metric(metrics, "false_abstention"),
                "unsupported_claim_rate": metric(metrics, "unsupported_claim_rate"),
                "total_seconds": number_or_blank(performance.get("total_seconds")),
                "parse_seconds": number_or_blank(performance.get("parse_seconds")),
                "index_seconds": number_or_blank(performance.get("index_seconds")),
                "retrieval_seconds": number_or_blank(performance.get("retrieval_seconds")),
                "generation_seconds": number_or_blank(performance.get("generation_seconds")),
                "controller_final_route": decision.get("final_route") or decision.get("legacy_route") or decision.get("route") or "",
                "controller_initial_route": decision.get("initial_route") or "",
                "controller_planner_route": decision.get("planner_route") or "",
                "controller_scored_route": decision.get("scored_route") or "",
                "controller_policy": decision.get("route_selection_policy") or decision.get("policy") or "",
                "route_switch_used": str(bool(decision.get("route_switch_used"))),
                "route_confidence_by_modality": compact_json(decision.get("route_confidence_by_modality")),
                "expected_route_cost": compact_json(decision.get("expected_route_cost")),
                "expected_route_quality": compact_json(decision.get("expected_route_quality")),
                "skipped_expensive_routes": compact_json(decision.get("skipped_expensive_routes")),
                "visual_backend_type": backend.get("visual_backend_type", ""),
                "text_retriever": backend.get("text_retriever", ""),
                "visual_retriever": backend.get("visual_retriever", ""),
                "generator_backend": backend.get("generator_backend", ""),
            }
        )
    return rows


def aggregate_main_rows(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for (dataset, route), items in grouped(records, "dataset", "route").items():
        rows.append(
            {
                "dataset": dataset,
                "route": route,
                "num_predictions": len(items),
                "num_errors": count_truthy(items, "error"),
                "route_timeout_count": count_equals(items, "error_type", "route_timeout"),
                "empty_answer_for_scoring_count": count_equals(items, "answer_for_scoring_empty", "True"),
                "avg_f1": mean_metric(items, "f1"),
                "avg_native_score": mean_metric(items, "native_score"),
                "avg_mara_score": mean_metric(items, "mara_score"),
                "avg_em": mean_metric(items, "em"),
                "avg_numeric_match": mean_metric(items, "numeric_match"),
                "avg_page_hit": mean_metric(items, "page_hit"),
                "avg_element_hit": mean_metric(items, "element_hit"),
                "avg_citation_inline_recall": mean_metric(items, "citation_inline_recall"),
                "avg_citation_metadata_recall": mean_metric(items, "citation_metadata_recall"),
                "false_abstention_rate": mean_metric(items, "false_abstention"),
                "avg_unsupported_claim_rate": mean_metric(items, "unsupported_claim_rate"),
                "avg_total_seconds": mean_metric(items, "total_seconds"),
                "avg_generation_seconds": mean_metric(items, "generation_seconds"),
                "route_switch_rate": mean_bool(items, "route_switch_used"),
                "artifact_dirs": compact_json(sorted({row["artifact_dir"] for row in items})),
            }
        )
    return sorted(rows, key=lambda row: (row["dataset"], row["route"]))


def aggregate_failure_latency_backend_rows(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for (dataset, route), items in grouped(records, "dataset", "route").items():
        rows.append(
            {
                "dataset": dataset,
                "route": route,
                "num_predictions": len(items),
                "error_count": count_truthy(items, "error"),
                "route_timeout_count": count_equals(items, "error_type", "route_timeout"),
                "error_type_counts": dump_counts(Counter(row["error_type"] for row in items if row["error_type"])),
                "avg_total_seconds": mean_metric(items, "total_seconds"),
                "p95_total_seconds": percentile_metric(items, "total_seconds", 0.95),
                "avg_parse_seconds": mean_metric(items, "parse_seconds"),
                "avg_index_seconds": mean_metric(items, "index_seconds"),
                "avg_retrieval_seconds": mean_metric(items, "retrieval_seconds"),
                "avg_generation_seconds": mean_metric(items, "generation_seconds"),
                "visual_backend_types": dump_counts(Counter(row["visual_backend_type"] for row in items if row["visual_backend_type"])),
                "text_retrievers": dump_counts(Counter(row["text_retriever"] for row in items if row["text_retriever"])),
                "visual_retrievers": dump_counts(Counter(row["visual_retriever"] for row in items if row["visual_retriever"])),
                "generator_backends": dump_counts(Counter(row["generator_backend"] for row in items if row["generator_backend"])),
            }
        )
    return sorted(rows, key=lambda row: (row["dataset"], row["route"]))


def route_decision_summary_rows(
    artifact: dict[str, Any],
    predictions: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    outer_route_counts = Counter(str(item.get("route") or "") for item in predictions)
    final_route_counts: Counter[str] = Counter()
    initial_route_counts: Counter[str] = Counter()
    planner_route_counts: Counter[str] = Counter()
    scored_route_counts: Counter[str] = Counter()
    policy_counts: Counter[str] = Counter()
    skipped_counts: Counter[str] = Counter()
    has_confidence = 0
    has_cost = 0
    has_quality = 0
    switch_count = 0
    controller_records = 0
    for item in predictions:
        decision = controller_decision(item)
        if not decision:
            continue
        controller_records += 1
        final_route_counts[str(decision.get("final_route") or decision.get("legacy_route") or decision.get("route") or "")] += 1
        initial_route_counts[str(decision.get("initial_route") or "")] += 1
        planner_route_counts[str(decision.get("planner_route") or "")] += 1
        scored_route_counts[str(decision.get("scored_route") or "")] += 1
        policy_counts[str(decision.get("route_selection_policy") or decision.get("policy") or "")] += 1
        if decision.get("route_switch_used"):
            switch_count += 1
        if decision.get("route_confidence_by_modality"):
            has_confidence += 1
        if decision.get("expected_route_cost"):
            has_cost += 1
        if decision.get("expected_route_quality"):
            has_quality += 1
        skipped = decision.get("skipped_expensive_routes")
        if isinstance(skipped, list):
            skipped_counts.update(str(route) for route in skipped)
    return [
        {
            "dataset": artifact["dataset"],
            "job_id": artifact["job_id"],
            "suite_name": artifact["suite_name"],
            "route_request": artifact["route_request"],
            "shard_index": artifact["shard_index"],
            "predictions": len(predictions),
            "controller_records": controller_records,
            "outer_route_counts": dump_counts(outer_route_counts),
            "final_route_counts": dump_counts(final_route_counts),
            "initial_route_counts": dump_counts(initial_route_counts),
            "planner_route_counts": dump_counts(planner_route_counts),
            "scored_route_counts": dump_counts(scored_route_counts),
            "policy_counts": dump_counts(policy_counts),
            "skipped_expensive_routes": dump_counts(skipped_counts),
            "route_switch_count": switch_count,
            "route_switch_rate": round(switch_count / len(predictions), 4) if predictions else "",
            "route_confidence_trace_rows": has_confidence,
            "expected_route_cost_rows": has_cost,
            "expected_route_quality_rows": has_quality,
            "artifact_dir": artifact["artifact_dir"],
        }
    ]


def statistical_rows(
    records: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    paired_rows: list[dict[str, Any]] = []
    bootstrap_rows: list[dict[str, Any]] = []
    win_loss_rows: list[dict[str, Any]] = []
    for dataset, pairs in PAIRED_ROUTE_PAIRS.items():
        scoped = [row for row in records if row["dataset"] == dataset]
        for baseline, candidate in pairs:
            paired = paired_route_delta_rows(
                scoped,
                baseline_route=baseline,
                candidate_route=candidate,
                metric="f1",
            )
            if not paired:
                continue
            paired_rows.extend(paired)
            bootstrap_rows.extend(
                bootstrap_ci_by_dataset_route(
                    scoped,
                    baseline_route=baseline,
                    candidate_route=candidate,
                    metric="f1",
                    iterations=1000,
                    seed=20260705,
                )
            )
            win_loss_rows.extend(
                route_win_loss_tie_rows(
                    scoped,
                    baseline_route=baseline,
                    candidate_route=candidate,
                    metric="f1",
                )
            )
    return paired_rows, bootstrap_rows, win_loss_rows


def controller_oracle_regret_by_dataset(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for dataset in sorted({row["dataset"] for row in records}):
        scoped = [row for row in records if row["dataset"] == dataset]
        rows.extend(
            controller_oracle_regret_rows(
                scoped,
                controller_route="controller_auto",
                metric="f1",
            )
        )
    return rows


def write_report(
    *,
    artifact_rows: list[dict[str, Any]],
    main_rows: list[dict[str, Any]],
    route_decision_rows: list[dict[str, Any]],
    failure_rows: list[dict[str, Any]],
    records: list[dict[str, Any]],
    paired_rows: list[dict[str, Any]],
    bootstrap_rows: list[dict[str, Any]],
    oracle_rows: list[dict[str, Any]],
    win_loss_rows: list[dict[str, Any]],
    blocked_reason: str,
) -> None:
    complete_jobs = sum(1 for row in artifact_rows if row["artifacts_complete"] == "True")
    required = {
        "main result table": (OUTPUTS["main"], len(main_rows)),
        "route decision summary": (OUTPUTS["route_decision"], len(route_decision_rows)),
        "failure / latency / backend table": (OUTPUTS["failure_latency_backend"], len(failure_rows)),
        "paired route delta": (OUTPUTS["paired_delta"], len(paired_rows)),
        "bootstrap CI by route": (OUTPUTS["bootstrap_ci"], len(bootstrap_rows)),
        "controller oracle regret": (OUTPUTS["controller_oracle_regret"], len(oracle_rows)),
        "win/loss/tie table": (OUTPUTS["win_loss_tie"], len(win_loss_rows)),
    }
    lines = [
        "# Statistical Full-System Synthesis Report",
        "",
        "Date: 2026-07-05",
        "",
        "## Input Coverage",
        "",
        f"- Slurm jobs submitted: {len(artifact_rows)}",
        f"- complete artifact sets: {complete_jobs}",
        f"- per-example prediction records loaded: {len(records)}",
        "",
        "| Job | Dataset | Route request | Shard | Predictions | Complete | Artifact dir |",
        "| --- | --- | --- | ---: | ---: | --- | --- |",
    ]
    for row in artifact_rows:
        lines.append(
            f"| {row['job_id']} | {row['dataset']} | {row['route_request']} | "
            f"{row['shard_index']} | {row['num_predictions']} | {row['artifacts_complete']} | "
            f"`{row['artifact_dir']}` |"
        )
    lines.extend(
        [
            "",
            "## Required Table Gate",
            "",
            "| Required output | Rows | Path | Status |",
            "| --- | ---: | --- | --- |",
        ]
    )
    for name, (path, count) in required.items():
        status = "PASS" if path.exists() and count > 0 else "FAIL"
        lines.append(f"| {name} | {count} | `{path}` | {status} |")
    lines.extend(["", "## Decision", ""])
    if blocked_reason and complete_jobs < len(artifact_rows):
        lines.append(f"PARTIAL: {blocked_reason}")
        lines.append("")
        lines.append("These tables are schema/progress outputs only and must not be used as final thesis results.")
    elif blocked_reason:
        lines.append(f"BLOCKED: {blocked_reason}")
    elif any(not path.exists() or count == 0 for path, count in required.values()):
        lines.append("FAIL: one or more required table families are missing or empty.")
    else:
        lines.append("PASS: all required final synthesis table families were generated.")
    OUTPUTS["report"].write_text("\n".join(lines) + "\n", encoding="utf-8")


def read_csv(path: Path, *, delimiter: str = ",") -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle, delimiter=delimiter))


def read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []
    with path.open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fieldnames = sorted({key for row in rows for key in row})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key, "") for key in fieldnames})


def grouped(rows: list[dict[str, Any]], *keys: str) -> dict[tuple[str, ...], list[dict[str, Any]]]:
    result: dict[tuple[str, ...], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        result[tuple(str(row.get(key) or "") for key in keys)].append(row)
    return result


def controller_decision(prediction: dict[str, Any]) -> dict[str, Any]:
    decision = prediction.get("controller_decision")
    if isinstance(decision, dict) and decision:
        return decision
    decision = prediction.get("route_decision")
    return decision if isinstance(decision, dict) else {}


def dict_or_empty(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def metric(metrics: dict[str, Any], key: str) -> float | str:
    return number_or_blank(metrics.get(key))


def number_or_blank(value: Any) -> float | str:
    if value is None:
        return ""
    try:
        return round(float(value), 4)
    except (TypeError, ValueError):
        return ""


def mean_metric(rows: list[dict[str, Any]], key: str) -> float | str:
    values = numeric_values(rows, key)
    if not values:
        return ""
    return round(sum(values) / len(values), 4)


def percentile_metric(rows: list[dict[str, Any]], key: str, fraction: float) -> float | str:
    values = sorted(numeric_values(rows, key))
    if not values:
        return ""
    index = min(max(round((len(values) - 1) * fraction), 0), len(values) - 1)
    return round(values[index], 4)


def numeric_values(rows: list[dict[str, Any]], key: str) -> list[float]:
    values: list[float] = []
    for row in rows:
        value = row.get(key)
        if value == "":
            continue
        try:
            values.append(float(value))
        except (TypeError, ValueError):
            continue
    return values


def mean_bool(rows: list[dict[str, Any]], key: str) -> float | str:
    if not rows:
        return ""
    return round(sum(1 for row in rows if row.get(key) == "True") / len(rows), 4)


def count_truthy(rows: list[dict[str, Any]], key: str) -> int:
    return sum(1 for row in rows if bool(str(row.get(key) or "").strip()))


def count_equals(rows: list[dict[str, Any]], key: str, expected: str) -> int:
    return sum(1 for row in rows if str(row.get(key) or "") == expected)


def dump_counts(counter: Counter[str]) -> str:
    return ";".join(f"{key}:{value}" for key, value in sorted(counter.items()) if key)


def compact_json(value: Any) -> str:
    if value in (None, "", [], {}):
        return ""
    return json.dumps(value, sort_keys=True, separators=(",", ":"))


if __name__ == "__main__":
    main()
