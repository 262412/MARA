# Statistical Full-System Synthesis Report

Date: 2026-07-05

## Input Coverage

- Slurm jobs submitted: 41
- complete artifact sets: 41
- per-example prediction records loaded: 3540

| Job | Dataset | Route request | Shard | Predictions | Complete | Artifact dir |
| --- | --- | --- | ---: | ---: | --- | --- |
| 9654005 | financebench | all | 0 | 200 | True | `<BENCHMARK_RUN_ROOT>/01_core_text/20260705_151401_stat-financebench-all-n50-shard00of3-9654005` |
| 9654006 | financebench | all | 1 | 200 | True | `<BENCHMARK_RUN_ROOT>/01_core_text/20260705_151128_stat-financebench-all-n50-shard01of3-9654006` |
| 9654007 | financebench | all | 2 | 200 | True | `<BENCHMARK_RUN_ROOT>/01_core_text/20260705_151132_stat-financebench-all-n50-shard02of3-9654007` |
| 9654008 | qasper | all | 0 | 150 | True | `<BENCHMARK_RUN_ROOT>/01_core_text/20260705_152224_stat-qasper-all-n50-shard00of4-9654008` |
| 9654009 | qasper | all | 1 | 150 | True | `<BENCHMARK_RUN_ROOT>/01_core_text/20260705_152138_stat-qasper-all-n50-shard01of4-9654009` |
| 9654010 | qasper | all | 2 | 150 | True | `<BENCHMARK_RUN_ROOT>/01_core_text/20260705_152128_stat-qasper-all-n50-shard02of4-9654010` |
| 9654011 | qasper | all | 3 | 150 | True | `<BENCHMARK_RUN_ROOT>/01_core_text/20260705_165312_stat-qasper-all-n50-shard03of4-9654011` |
| 9654012 | ragtruth | all | 0 | 150 | True | `<BENCHMARK_RUN_ROOT>/01_core_text/20260705_165347_stat-ragtruth-all-n50-shard00of6-9654012` |
| 9654013 | ragtruth | all | 1 | 150 | True | `<BENCHMARK_RUN_ROOT>/01_core_text/20260705_165939_stat-ragtruth-all-n50-shard01of6-9654013` |
| 9654014 | ragtruth | all | 2 | 150 | True | `<BENCHMARK_RUN_ROOT>/01_core_text/20260705_181354_stat-ragtruth-all-n50-shard02of6-9654014` |
| 9654015 | ragtruth | all | 3 | 150 | True | `<BENCHMARK_RUN_ROOT>/01_core_text/20260705_182110_stat-ragtruth-all-n50-shard03of6-9654015` |
| 9654016 | ragtruth | all | 4 | 150 | True | `<BENCHMARK_RUN_ROOT>/01_core_text/20260705_183014_stat-ragtruth-all-n50-shard04of6-9654016` |
| 9654017 | ragtruth | all | 5 | 150 | True | `<BENCHMARK_RUN_ROOT>/01_core_text/20260705_183652_stat-ragtruth-all-n50-shard05of6-9654017` |
| 9654018 | alce_asqa | all | 0 | 150 | True | `<BENCHMARK_RUN_ROOT>/01_core_text/20260705_184737_stat-alce-asqa-all-n50-shard00of4-9654018` |
| 9654019 | alce_asqa | all | 1 | 150 | True | `<BENCHMARK_RUN_ROOT>/01_core_text/20260705_185524_stat-alce-asqa-all-n50-shard01of4-9654019` |
| 9654020 | alce_asqa | all | 2 | 150 | True | `<BENCHMARK_RUN_ROOT>/01_core_text/20260705_190450_stat-alce-asqa-all-n50-shard02of4-9654020` |
| 9654021 | alce_asqa | all | 3 | 150 | True | `<BENCHMARK_RUN_ROOT>/01_core_text/20260705_191334_stat-alce-asqa-all-n50-shard03of4-9654021` |
| 9654022 | slidevqa | all | 0 | 60 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_144327_stat-slidevqa-all-n30-shard00of4` |
| 9654023 | slidevqa | all | 1 | 60 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_144843_stat-slidevqa-all-n30-shard01of4` |
| 9654024 | slidevqa | all | 2 | 60 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_145444_stat-slidevqa-all-n30-shard02of4` |
| 9654025 | slidevqa | all | 3 | 60 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_150044_stat-slidevqa-all-n30-shard03of4` |
| 9654026 | mmdocrag | text_rag | 0 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_192827_stat-mmdocrag-text-rag-n30-shard00of4` |
| 9654027 | mmdocrag | text_rag | 1 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_193753_stat-mmdocrag-text-rag-n30-shard01of4` |
| 9656204 | mmdocrag | text_rag | 2 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_194547_stat-mmdocrag-text-rag-n30-shard02of4-repair2-missingpdfs` |
| 9654029 | mmdocrag | text_rag | 3 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_193049_stat-mmdocrag-text-rag-n30-shard03of4` |
| 9654030 | mmdocrag | element_rag | 0 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_195232_stat-mmdocrag-element-rag-n30-shard00of4` |
| 9654031 | mmdocrag | element_rag | 1 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_195227_stat-mmdocrag-element-rag-n30-shard01of4` |
| 9654032 | mmdocrag | element_rag | 2 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_195759_stat-mmdocrag-element-rag-n30-shard02of4` |
| 9654033 | mmdocrag | element_rag | 3 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_200423_stat-mmdocrag-element-rag-n30-shard03of4` |
| 9658093 | mmdocrag | controller_auto | 0 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_210531_stat-mmdocrag-controller-auto-n30-shard00of4-repair-t360` |
| 9658094 | mmdocrag | controller_auto | 1 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_210406_stat-mmdocrag-controller-auto-n30-shard01of4-repair-t360` |
| 9658095 | mmdocrag | controller_auto | 2 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_211029_stat-mmdocrag-controller-auto-n30-shard02of4-repair-t360` |
| 9658096 | mmdocrag | controller_auto | 3 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_212147_stat-mmdocrag-controller-auto-n30-shard03of4-repair-t360` |
| 9654038 | mmdocrag | page_image_rag_vlm | 0 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_214541_stat-mmdocrag-page-image-rag-vlm-n30-shard00of4` |
| 9654039 | mmdocrag | page_image_rag_vlm | 1 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_214340_stat-mmdocrag-page-image-rag-vlm-n30-shard01of4` |
| 9654040 | mmdocrag | page_image_rag_vlm | 2 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_214457_stat-mmdocrag-page-image-rag-vlm-n30-shard02of4` |
| 9654041 | mmdocrag | page_image_rag_vlm | 3 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_220611_stat-mmdocrag-page-image-rag-vlm-n30-shard03of4` |
| 9654042 | mmdocrag | hybrid_rag | 0 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_223307_stat-mmdocrag-hybrid-rag-n30-shard00of4` |
| 9654043 | mmdocrag | hybrid_rag | 1 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_223212_stat-mmdocrag-hybrid-rag-n30-shard01of4` |
| 9654044 | mmdocrag | hybrid_rag | 2 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_223258_stat-mmdocrag-hybrid-rag-n30-shard02of4` |
| 9654045 | mmdocrag | hybrid_rag | 3 | 30 | True | `<BENCHMARK_RUN_ROOT>/05_page_image_vlm/20260705_225619_stat-mmdocrag-hybrid-rag-n30-shard03of4` |

## Required Table Gate

| Required output | Rows | Path | Status |
| --- | ---: | --- | --- |
| main result table | 20 | `<SYNTHESIS_DIR>/statistical_main_result_table.csv` | PASS |
| route decision summary | 41 | `<SYNTHESIS_DIR>/statistical_route_decision_summary.csv` | PASS |
| failure / latency / backend table | 20 | `<SYNTHESIS_DIR>/statistical_failure_latency_backend_table.csv` | PASS |
| paired route delta | 2450 | `<SYNTHESIS_DIR>/statistical_paired_route_delta.csv` | PASS |
| bootstrap CI by route | 14 | `<SYNTHESIS_DIR>/statistical_bootstrap_ci_by_route.csv` | PASS |
| controller oracle regret | 1090 | `<SYNTHESIS_DIR>/statistical_controller_oracle_regret.csv` | PASS |
| win/loss/tie table | 14 | `<SYNTHESIS_DIR>/statistical_win_loss_tie_table.csv` | PASS |

## Decision

PASS: all required final synthesis table families were generated.
