﻿Overleaf entry points:
- main.tex: named/preprint demo paper
- paper_anonymous.tex: anonymous review version
- paper_venue.tex: venue-facing version

Compiler: pdfLaTeX
Bibliography: BibTeX (acl_natbib.bst)
Main figure asset: figures/mara-ui-qa.png